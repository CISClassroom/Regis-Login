<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Result</title>
</head>
<body>
    <?php

     $getAns = $_POST['Ans'];
     $getID = $_GET['id'];
     $link = mysqli_connect("", "", "", "");
     $sql = "SELECT * FROM login_user where Email='$getEmail' and answer='$getAns'";
     $res = mysqli_query($link, $sql);
     
     if (!$data = mysqli_fetch_array($res)) {
        echo "<a href='login.html'>Login</a>";
     } else {
        Roitip | Forgot  username
        echo $Email['Email'] ;
         echo "</form>";
     }

    ?>
</body>
</html>